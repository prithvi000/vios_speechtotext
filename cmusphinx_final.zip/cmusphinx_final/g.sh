#!/bin/bash  
sudo apt-get install gcc automake autoconf libtool bison swig python-dev libpulse-dev

mkdir speech_recognition
cd speech_regognition

git init
git clone https://github.com/cmusphinx/sphinxbase.git
cd "sphinxbase"
./autogen.sh
./configure
make clean all
make check
sudo make install
export LD_LIBRARY_PATH=/usr/local/lib
export PKG_CONFIG_PATH=/usr/local/lib/pkgconfig/usr/local/lib

cd ..
git clone https://github.com/cmusphinx/pocketsphinx.git

cd "pocketsphinx"
./autogen.sh
./configure
make clean all
make check
sudo make install

cd ..
git clone https://github.com/cmusphinx/sphinxtrain.git
cd sphinxtrain
./autogen.sh
./configure
make clean all
make check
sudo make install
cd ..

sudo apt install subversion
svn checkout svn://svn.code.sf.net/p/cmusphinx/code/trunk cmusphinx-code
cd "cmusphinx-code"
cd "cmuclmtk"
./autogen.sh
./configure
make clean all
make check
sudo make install

cd ..
cd ..

pocketsphinx_continuous -lm 6633.lm -dict 6633.dic -infile pc2.wav > pc2.txt
pocketsphinx_continuous -lm 6633.lm -dict 6633.dic -infile pc2.wav > pc2.txt
